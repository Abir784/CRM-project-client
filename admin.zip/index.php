<?php

define('APP_RUN', true);
require 'system/app.php';
