<?php
/* Smarty version 3.1.39, created on 2021-04-28 15:37:07
  from '/Users/razib/Documents/valet/business-suite/apps/blog/views/post.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6089b96310b184_27628307',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1eda6f59aa98c82af957c11ad94253ae09b892b6' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/apps/blog/views/post.tpl',
      1 => 1619638624,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6089b96310b184_27628307 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['layouts_admin']->value));
}
}
