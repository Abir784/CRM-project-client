<?php
/* Smarty version 3.1.39, created on 2021-05-17 12:10:02
  from '/Users/razib/Documents/valet/business-suite/ui/theme/default/marketing_crm/emails/preview.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60a2955a13f044_99025191',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f061dfed585f6fd3531bf5e637f2233545048b54' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/default/marketing_crm/emails/preview.tpl',
      1 => 1621267733,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60a2955a13f044_99025191 (Smarty_Internal_Template $_smarty_tpl) {
?><h4><?php echo $_smarty_tpl->tpl_vars['subject']->value;?>
</h4>
<div class="hr-line-dashed"></div>
<?php echo $_smarty_tpl->tpl_vars['body_html']->value;?>

<?php }
}
