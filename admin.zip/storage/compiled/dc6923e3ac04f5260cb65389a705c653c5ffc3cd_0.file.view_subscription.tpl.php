<?php
/* Smarty version 3.1.39, created on 2021-12-20 14:08:20
  from '/Users/razib/Documents/valet/business-suite/ui/theme/default/view_subscription.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61c0d4a4061dc4_82749402',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dc6923e3ac04f5260cb65389a705c653c5ffc3cd' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/default/view_subscription.tpl',
      1 => 1640027099,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61c0d4a4061dc4_82749402 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1655310261c0d4a4060644_81564328', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_137726203261c0d4a4061740_60125211', 'script');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "layouts/paper.tpl");
}
/* {block "content"} */
class Block_1655310261c0d4a4060644_81564328 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1655310261c0d4a4060644_81564328',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


kk

<?php
}
}
/* {/block "content"} */
/* {block 'script'} */
class Block_137726203261c0d4a4061740_60125211 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_137726203261c0d4a4061740_60125211',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php echo '<script'; ?>
>

    <?php echo '</script'; ?>
>


<?php
}
}
/* {/block 'script'} */
}
