<?php
/* Smarty version 3.1.39, created on 2021-02-26 17:45:05
  from '/Users/razib/Documents/valet/business-suite/apps/20i/views/users.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_603979f1651828_96042094',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bc73a7b466b1391def2dd44164e73650e18c4ee2' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/apps/20i/views/users.tpl',
      1 => 1614379502,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_603979f1651828_96042094 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1077715656603979f164f0f3_37942229', "content");
?>


<?php }
/* {block "content"} */
class Block_1077715656603979f164f0f3_37942229 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1077715656603979f164f0f3_37942229',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="card">
        <div class="card-body">
            <h3>Users</h3>
            <div class="hr-line-dashed"></div>
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Domain</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                        dd
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php
}
}
/* {/block "content"} */
}
