<?php
header('location: ../?ng=updating');